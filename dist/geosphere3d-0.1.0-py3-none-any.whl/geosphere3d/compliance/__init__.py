"""Geospatial compliance checking."""
